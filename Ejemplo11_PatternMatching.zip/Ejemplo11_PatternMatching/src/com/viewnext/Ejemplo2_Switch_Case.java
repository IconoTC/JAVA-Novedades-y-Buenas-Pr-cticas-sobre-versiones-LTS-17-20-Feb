package com.viewnext;

import java.util.Scanner;

public class Ejemplo2_Switch_Case {

	public static void main(String[] args) {
		// Solicitar el numero del mes al usuario
		// utilizando switch-case decir cuantos dias tiene
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el numero del mes: ");
		int mes = sc.nextInt();
		
		int dias = switch (mes) {
			case 1,3,5,7,8,10,12 -> 31;
			case 2 -> 28;
			case 4,6,9,11 -> 30;
			default -> throw new IllegalArgumentException("Ese mes no existe");
		};
		
		System.out.println("El mes " + mes + " tiene " + dias + " dias");

	}

}
