/**
 * 
 */
/**
 * 
 */
module Ejercicio06_Servicio_Consumidor_Calculadora {
	
	requires Ejercicio04_Servicio_Calculadora;
	uses com.viewnext.interfaz.ItfzCalculadora;
}