package com.viewnext;

import java.util.ServiceLoader;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import com.viewnext.interfaz.ItfzCalculadora;

public class AppMain {

	public static void main(String[] args) {
		ServiceLoader<ItfzCalculadora> loader = ServiceLoader.load(ItfzCalculadora.class);
		Iterable<ItfzCalculadora> iterable = () -> loader.iterator();
		Stream<ItfzCalculadora> stream = StreamSupport.stream(iterable.spliterator(), false);
		
		ItfzCalculadora calculadora = stream.findAny().get();
		
		System.out.println("7 + 2 = " + calculadora.sumar(7, 2));
		System.out.println("7 - 2 = " + calculadora.restar(7, 2));
		System.out.println("7 * 2 = " + calculadora.multiplicar(7, 2));
		System.out.println("7 / 2 = " + calculadora.dividir(7, 2));

	}

}
