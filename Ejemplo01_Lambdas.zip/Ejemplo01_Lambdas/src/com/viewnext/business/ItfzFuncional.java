package com.viewnext.business;

// Una interface funcional tiene que tener UN SOLO metodo abstracto
@FunctionalInterface
public interface ItfzFuncional<T extends CharSequence> {
	
	String infoPersonas(T nombre, int edad);

}
