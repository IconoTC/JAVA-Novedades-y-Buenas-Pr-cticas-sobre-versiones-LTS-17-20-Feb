package com.viewnext;

import com.viewnext.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		// Sintaxis:  parametros    ->    cuerpo de la funcion
		
		
		// Los nombres de los parametros no tienen porque llamarse igual
		// Al ser 2 parametros es obligatorio usar los parentesis
		// No es obligatorio poner el tipo de datos de los parametros
		// Si el cuerpo de la funcion es una sola linea tampoco es obligatorio las {}
		ItfzFuncional<CharSequence> lambda1 = (n, e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda1.infoPersonas("Pepito", 25));
		
		// Si ponemos el tipo es obligatorio los ()
		ItfzFuncional<String> lambda2 = (String n, int e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda2.infoPersonas("Pepito", 25));
		
		// Si ponemos {} hay que colocar el return
		ItfzFuncional<CharSequence> lambda3 = (n, e) -> {
			return "nombre: " + n + " edad: " + e;
		};
		System.out.println(lambda3.infoPersonas("Pepito", 25));
		
		// Si tenemos mas de una linea de cuerpo de metodo es obligatorio las llaves
		ItfzFuncional lambda4 = (nombre, edad) -> {
			edad++;
			nombre = nombre.toString().toUpperCase();
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda4.infoPersonas("Pepito", 25));
		
		// Inferencia de tipos
		ItfzFuncional lambda5 = (var nombre, var edad) -> {
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda5.infoPersonas("Pepito", 25));

	}

}







