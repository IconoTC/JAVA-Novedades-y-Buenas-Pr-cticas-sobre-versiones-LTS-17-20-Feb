package com.viewnext;

import com.viewnext.models.Circulo;
import com.viewnext.models.Figura;
import com.viewnext.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		Figura circulo = new Circulo(56);
		System.out.println("Area del circulo: " + circulo.calcularArea());
		
		// Rectangulo no hereda de Figura y no puede utilizarse como tipo
		//Figura rectangulo = new Rectangulo(50, 20);
		Rectangulo rectangulo = new Rectangulo(50, 20);
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());

	}

}
