package com.viewnext.models;

public class Elipse extends Circulo{

}
