/**
 * 
 */
/**
 * 
 */
module Ejemplo23_Clases_selladas {
}