package com.viewnext;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class AppMain {

	public static void main(String[] args) throws ScriptException {
		
		/*
		 * IMPORTANTE!!! el proyecto debe estar configurado con Java 8
		 * */
		
		// Obtener una instancia del motor JS
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine nashorm  = manager.getEngineByName("nashorn");
		
		// Cargar y ejecutar el script
		nashorm.eval("load('prueba.js')");
		
		// Ejecutar codigo JS
		nashorm.eval("print('Hola')");

	}

}
