package com.viewnext;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class EjemplosLocalDateTime {

	public static void main(String[] args) {
		
		// El vuelo es el 10 de agosto de 2025 a las 21:30
		LocalDateTime vuelo = LocalDateTime.of(2025, Month.AUGUST, 10, 21, 30);
		System.out.println(vuelo);
		
		// Otra forma
		LocalDate fecha = LocalDate.of(2025, Month.AUGUST, 10);
		LocalTime hora = LocalTime.of(21, 30);
		LocalDateTime vuelo2 = LocalDateTime.of(fecha, hora);
		System.out.println(vuelo2);
		
		// Aplazar el vuelo 1 semana
		System.out.println(vuelo.plusWeeks(1));
		
		// Adelantar el vuelo 1 semana
		System.out.println(vuelo.minusWeeks(1));

	}

}
