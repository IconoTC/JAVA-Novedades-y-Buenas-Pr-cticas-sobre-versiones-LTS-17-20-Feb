package com.viewnext;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class EjemplosLocalDate {

	public static void main(String[] args) {
		
		// Fecha actual
		LocalDate hoy = LocalDate.now();
		System.out.println(hoy);
		
		// Fecha de mi cumpleaños
		LocalDate miCumple = LocalDate.of(2025, Month.JULY, 1);
		
		// Ya ha sido tu cumpleaños?
		System.out.println("Ya ha sido tu cumpleaños? " + miCumple.isAfter(hoy));
		System.out.println("Ya ha sido tu cumpleaños? " + hoy.isBefore(miCumple));
		
		// En que dia de la semana cae mi cumpleaños
		System.out.println("Dia de mi cumple: " + miCumple.getDayOfWeek());
		
		// Este año es bisiesto
		System.out.println(hoy.isLeapYear());
		
		// Sumar un mes
		System.out.println("Dentro de un mes: " + hoy.plusMonths(1));
		
		// Restar un año
		System.out.println("Hace un año: " + hoy.minusYears(1));
		
		// Fecha del proximo domingo
		System.out.println("Proximo domingo: " + hoy.with(TemporalAdjusters.next(DayOfWeek.SUNDAY)));

	}

}
