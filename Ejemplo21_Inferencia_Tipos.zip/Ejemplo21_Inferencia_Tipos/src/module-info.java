/**
 * 
 */
/**
 * 
 */
module Ejemplo21_Inferencia_Tipos {
}