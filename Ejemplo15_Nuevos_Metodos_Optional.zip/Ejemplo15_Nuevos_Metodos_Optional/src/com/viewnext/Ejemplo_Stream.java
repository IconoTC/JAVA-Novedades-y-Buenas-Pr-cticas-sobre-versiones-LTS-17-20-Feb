package com.viewnext;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Ejemplo_Stream {

	public static void main(String[] args) {
		
		Optional<String> op = Optional.of("     Hola Juan como estas?       ");
		
		// Primero quitar los espacios derecha e izquierda
		// partir el texto por " " (split)
		// mostrar en consola
		op.stream()
			.map(texto -> texto.strip())
			.map(texto -> Arrays.stream(texto.split(" ")))
			.forEach(x -> x.forEach(System.out::println));
		
		
		// Primero quitar los espacios derecha e izquierda
		// partir el texto por " " (split)
		// sumamos caracteres
		int sumaPalabras = op.stream()
			.map(String::strip)
			.map(texto -> Arrays.asList(texto.split(" ")))
			.mapToInt(List::size)
			.sum();
		System.out.println(sumaPalabras);

	}

}
