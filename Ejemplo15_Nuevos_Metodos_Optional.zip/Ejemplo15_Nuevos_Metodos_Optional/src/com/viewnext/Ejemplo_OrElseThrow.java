package com.viewnext;

import java.util.Optional;

public class Ejemplo_OrElseThrow {
	
	public static void main(String[] args) {
		
		Optional<String> op = Optional.ofNullable(null);
		//Optional<String> op = Optional.ofNullable("Hola");
		
		// Si el optional esta vacio lanzamos una excepcion
		// Si no lo esta, mostreremos el valor
		
		// java.util.NoSuchElementException: No value present
//		String valor = op.orElseThrow();
//		System.out.println(valor);
		
		
		// Lanzo una excepcion personalizada (elijo el tipo y el mensaje)
		String valor = op.orElseThrow(() -> new RuntimeException("Ese valor es nulo") );
		System.out.println(valor);
	}

}
