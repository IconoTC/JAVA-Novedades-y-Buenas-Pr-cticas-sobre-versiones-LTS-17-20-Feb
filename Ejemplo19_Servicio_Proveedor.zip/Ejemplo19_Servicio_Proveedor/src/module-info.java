/**
 * 
 */
/**
 * 
 */
module Ejemplo19_Servicio_Proveedor {
	
	// requires nombre_modulo
	requires Ejemplo18_Servicio_Interface;
	
	// Proporcionar la clase que implementa la interface
	provides com.viewnext.interfaz.ItfzSaludo with com.viewnext.business.Saludo;
}