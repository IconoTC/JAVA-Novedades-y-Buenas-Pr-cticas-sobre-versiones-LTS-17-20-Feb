/**
 * 
 */
/**
 * 
 */
module Ejemplo20_Servicio_Consumidor {
	
	// Modulo donde esta declarada la interface
	requires Ejemplo18_Servicio_Interface;
	
	// Necesito indicar cual es la interface a utilizar
	uses com.viewnext.interfaz.ItfzSaludo;
}