package com.viewnext;

public class PatronGuarded {

	public static void main(String[] args) {
		
		Object dato = "pepito@gmail.com";
		
		// Funciona con Java 21
		String mensaje = switch (dato) {
			case String s -> {
				if (s.length() <= 5) {
					yield "Email no valido";
				} else if (! s.contains("@")) {
					yield "Email no valido";
				} else if (!s.contains(".")) {
					yield "Email no valido";
				} else {
					yield "Email valido";
				}
			}   
		
			default -> "Email valido";
			
		};
		
		System.out.println(mensaje);

	}

}
