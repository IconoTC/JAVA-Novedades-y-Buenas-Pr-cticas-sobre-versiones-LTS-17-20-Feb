package com.viewnext;

public class PatronParenthesized {

	public static void main(String[] args) {
		
		Object dato = "pepito@gmail.com";
		
		// Funciona con Java 21
		String mensaje = switch (dato) {
			case String s when (s.length() > 5 && s.contains("@") && s.contains(".")) -> "Email valido";
		
	
			default -> throw new IllegalArgumentException("Email no valido");
		};
		
		System.out.println(mensaje);

	}

}
