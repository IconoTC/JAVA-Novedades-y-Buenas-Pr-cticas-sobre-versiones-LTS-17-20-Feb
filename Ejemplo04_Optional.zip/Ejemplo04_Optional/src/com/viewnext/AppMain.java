package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		// Buscar un producto existente
		System.out.println(dao.buscarProducto(3));  // Optional<Producto>
		System.out.println(dao.buscarProducto(3).get());  // Producto
		
		// Buscar un producto que NO EXISTE
		System.out.println(dao.buscarProducto(35534)); // Optional.empty
		// java.util.NoSuchElementException: No value present
		//System.out.println(dao.buscarProducto(35534).get());
		
		
		// Primera forma de evitar la excepcion
		System.out.println(dao.buscarProducto(35534).orElse(new Producto()));
		
		
		// Segunda forma de evitar la excepcion
		Optional<Producto> opProducto = dao.buscarProducto(35534);
		if (opProducto.isPresent()) {
			System.out.println(opProducto.get());
		} else {
			System.out.println("Ese producto no existe en nuestro catalogo");
		}
		
		
		// Tercera forma de evitar la excepcion
		if (opProducto.isEmpty()) {
			System.out.println("Ese producto no existe en nuestro catalogo");
		} else {
			System.out.println(opProducto.get());
		}
		
		
		System.out.println(dao.buscarProducto(11).isPresent() ? dao.buscarProducto(11).get() : "No existe el producto en nuestro catálogo");
		System.out.println(dao.buscarProducto(11).isEmpty() ? "No existe el producto en nuestro catálogo" : dao.buscarProducto(11).get());
	}

}
