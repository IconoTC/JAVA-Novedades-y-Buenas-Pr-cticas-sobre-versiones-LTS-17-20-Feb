/**
 * 
 */
/**
 * 
 */
module Ejemplo17_Usar_Modulo {
	
	// Para poder usar el modulo de otro proyecto
	// es necesario agregarlo como dependencia en el build path
	
	// requires nombre_modulo
	requires Ejemplo16_Crear_Modulo;
}