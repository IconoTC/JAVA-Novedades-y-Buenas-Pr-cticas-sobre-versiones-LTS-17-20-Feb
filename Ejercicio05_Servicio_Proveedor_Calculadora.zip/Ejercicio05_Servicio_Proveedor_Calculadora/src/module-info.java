/**
 * 
 */
/**
 * 
 */
module Ejercicio05_Servicio_Proveedor_Calculadora {
	
	requires Ejercicio04_Servicio_Calculadora;
	provides com.viewnext.interfaz.ItfzCalculadora with com.viewnext.business.Calculadora;
}