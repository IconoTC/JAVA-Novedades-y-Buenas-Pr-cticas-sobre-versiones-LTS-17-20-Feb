package com.viewnext;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		// repeat
		System.out.println("-".repeat(20));
		System.out.println("*".repeat(20));
		System.out.println("ja".repeat(20));
		
		// strip
		String nombre = "      Juan    ";
		System.out.println(nombre + ".");
		
		// Quitar los espacios de izquierda y derecha
		System.out.println(nombre.strip() + ".");
		
		// Quitar solo los espacios de la izquierda
		System.out.println(nombre.stripLeading() + ".");
		
		// Quitar solo los espacios de la derecha
		System.out.println(nombre.stripTrailing() + ".");
		
		// lines
		String texto = "Hola\nque\ntal?";
		System.out.println(texto);
		texto.lines()  // genera un flujo con las 3 lineas de texto
			.map(dato -> dato.toUpperCase())
			.forEach(System.out::println);

	}

}
