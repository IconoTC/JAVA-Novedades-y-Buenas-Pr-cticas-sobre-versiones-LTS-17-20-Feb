/**
 * 
 */
/**
 * 
 */
module Ejemplo12_Constantes_JVM {
}