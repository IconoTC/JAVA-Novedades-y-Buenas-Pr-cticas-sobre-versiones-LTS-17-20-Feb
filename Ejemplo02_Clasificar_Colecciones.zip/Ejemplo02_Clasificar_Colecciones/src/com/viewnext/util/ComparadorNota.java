package com.viewnext.util;

import java.util.Comparator;

import com.viewnext.models.Alumno;

public class ComparadorNota implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// 1 o cualquier otro numero positivo alum1 > alum2
		// -1 o cualquier otro numero negativo alum1 < alum2
		// 0 si son iguales
		
		if (alum1.getNota() > alum2.getNota()) {
			return 1;
		} else if (alum1.getNota() < alum2.getNota()) {
			return -1;
		} else {
			return 0;
		}
	}

	

}
