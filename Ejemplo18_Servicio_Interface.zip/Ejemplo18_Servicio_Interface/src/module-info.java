/**
 * 
 */
/**
 * 
 */
module Ejemplo18_Servicio_Interface {
	
	// exports paquete
	exports com.viewnext.interfaz;
}