package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Ejemplo_Rutas {

	public static void main(String[] args) throws IOException {
		
		// A partir de Java 5 java.nio.file:
		//		- Path, interfaz que representa una ruta
		//		- Paths, clase para crear las instancias de Path
		//		- Files, clase con metodos estaticos para manejo de ficheros o rutas
		
		// Formas para obtener la ruta de un fichero
		Path path = Paths.get("/Users/anaisabelvegascaceres/sintaxis.sps");
		Path path2 = Path.of("/Users/anaisabelvegascaceres/sintaxis.sps");
		
		// Nombre del fichero
		System.out.println(path.getFileName());
		
		// Ruta del fichero
		System.out.println(path.toAbsolutePath());
		
		// Numero de elementos sin contar el raiz
		System.out.println(path.getNameCount());
		
		
		Path fichero = Paths.get("/Users/anaisabelvegascaceres/Desktop/prueba.txt");
		
		// Borrar el fichero si existe
		Files.deleteIfExists(fichero);
		
		// Crear el fichero
		Files.createFile(fichero);
		
		// Copiar el fichero
		Path destino = Paths.get("/Users/anaisabelvegascaceres/Desktop/prueba2.txt");
		Files.copy(fichero, destino);
		
		// Borrar el fichero original
		Files.delete(fichero);
		
		// Mover el fichero
		Path otraUbicacion = Paths.get("/Users/anaisabelvegascaceres/Documents/prueba2.txt");
		Files.move(destino, otraUbicacion);

	}

}
