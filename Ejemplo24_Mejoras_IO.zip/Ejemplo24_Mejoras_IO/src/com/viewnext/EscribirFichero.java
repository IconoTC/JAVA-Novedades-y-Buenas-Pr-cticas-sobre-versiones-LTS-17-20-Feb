package com.viewnext;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class EscribirFichero {

	public static void main(String[] args) {
		
		// try con recursos
		// Los recursos que se abren dentro de los parentesis del bloque try
		// y ademas AutoCloseables, se cierran solos
		// No es necesario llamar al metodo close
		try (FileWriter fichero = new FileWriter("datos.txt");
			 BufferedWriter bw = new BufferedWriter(fichero);){
			
			// Escribir contenido en el fichero
			bw.write("Hola");
			bw.write("\n");
			bw.write("Como estas?\n");
			bw.write("Mañana es viernes");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
