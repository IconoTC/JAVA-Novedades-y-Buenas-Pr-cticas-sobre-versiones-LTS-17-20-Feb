package com.viewnext;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import com.viewnext.models.Empleado;

public class SerializarObjetos {

	public static void main(String[] args) {
		
		Empleado empleado = new Empleado(1, "Maria", 57000);
		
		try (FileOutputStream fichero = new FileOutputStream("empleado.ser");
				ObjectOutputStream outputStream = new ObjectOutputStream(fichero)){
			
			// Serializacion
			outputStream.writeObject(empleado);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
